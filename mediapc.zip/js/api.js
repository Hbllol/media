var api = 'http://192.168.20.55:8082/v1/';
//首页轮播图
var homebannner = 'DsMedia/GetBanner';
//首页ioc列表
var homeicolist = 'DsMedia/GetHomeIcoList';
//营销顾问列表-首页-右侧展开二维码
var ConsultantList = 'DsMedia/GetConsultantList';
//Slogan信息
var Slogan = 'DsMedia/GetSlogan';
//首页案例列表
var HomeGallerytList = 'DsMedia/GetHomeGallerytList';
//首页合作伙伴列表接口
var HomePartner = 'DsMedia/GetHomePartner';
//案例列表
var GallerytList = 'DsMedia/GetGallerytList';
//案例详情
var GalleryDetail = 'DsMedia/GetGalleryDetail';
//服务项列表
var ServiceList = 'DsMedia/GetServiceList';
//团队列表
var TeamList = 'DsMedia/GetTeamList';